from random import randint
from random import choice


start_word = 'What is the result of the expression?'
number = randint(1, 25)


def play():
    num1 = number
    num2 = number
    decision = choice('+-*')
    if decision == '+':
        result = num1 + num2
    if decision == '-':
        result = num1 - num2
    else:
        num1 * num2
    return result
