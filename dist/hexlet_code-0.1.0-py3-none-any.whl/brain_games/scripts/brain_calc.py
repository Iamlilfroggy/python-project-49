import greet
import games.brain_calc


def main():
    greet.start(games.brain_calc)
    if __name__ == '__main__':
        main()
