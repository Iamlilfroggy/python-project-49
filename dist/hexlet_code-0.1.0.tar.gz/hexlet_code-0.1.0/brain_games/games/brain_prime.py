from random import randint


start_word = 'Answer "yes" if given number is prime. Otherwise answer "no".'


def play():
    num1 = randint(1, 270)
    question = num1
    for i in range(2, int(num1 / 2) + 1):
        if num1 % i == 0:
            result = 'no'
        else:
            result = 'yes'
        return question, result
