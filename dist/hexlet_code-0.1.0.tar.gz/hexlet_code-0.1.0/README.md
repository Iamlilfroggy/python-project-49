### Hexlet tests and linter status:
[![Actions Status](https://github.com/Iamlilfroggy/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Iamlilfroggy/python-project-49/actions)
<a href="https://codeclimate.com/github/Iamlilfroggy/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fa0a429ed18b562a7606/maintainability" /></a>