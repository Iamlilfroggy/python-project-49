# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Entartaining project with 5 simple mathematical games.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Iamlilfroggy/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Iamlilfroggy/python-project-49/actions)\n<a href="https://codeclimate.com/github/Iamlilfroggy/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fa0a429ed18b562a7606/maintainability" /></a>\n\n# Description\n\nThis project is a small entartainment package of 5 console mathematical games. You have to give 3 correct answers for each quiz, wrong answer terminates game.\n\n* brain-even\n\nGuess whether the shown number is even or not.\n\n* brain-calc\n\nGuess the result of simple mathematic expression.\n\n* brain-gcd\n\nGuess the greatest common divisor of two given numbers.\n\n* brain-progression\n\nGuess the missing number in given progression.\n\n* brain-prime\n\nGuess whether the given number is prime or not.\n\n# Minimum requirements\npython 3.10\n\n# Installation guide\nTo install the package for an end-user\nExecute:\n\npython3 -m pip install --user dist/*.whl\n\nIf you would like to install it as a developer\nTo install all dependencies execute:\n\nmake install\n\nTo build a package execute:\n\nmake build\n\nTo install the package execute:\n\nmake package-install\n\n# Scripts demo\n\npackage installation\n<a href="https://asciinema.org/a/nEzcZ9k5moW1s3ZzTmJi3SEQu" target="_blank"><img src="https://asciinema.org/a/nEzcZ9k5moW1s3ZzTmJi3SEQu.svg" /></a>\n\nbrain-even\n<a href="https://asciinema.org/a/fHt19nDPAbUJ2cjbue0uzouje" target="_blank"><img src="https://asciinema.org/a/fHt19nDPAbUJ2cjbue0uzouje.svg" /></a>\n\nbrain-calc\n<a href="https://asciinema.org/a/Puiz55KM9pufMgEbhvgjDjl2x" target="_blank"><img src="https://asciinema.org/a/Puiz55KM9pufMgEbhvgjDjl2x.svg" /></a>\n\nbrain-gcd\n<a href="https://asciinema.org/a/XK97v1vPdlFW9PJo64BMxFUpd" target="_blank"><img src="https://asciinema.org/a/XK97v1vPdlFW9PJo64BMxFUpd.svg" /></a>\n\nbrain-progression\n<a href="https://asciinema.org/a/TeuRBLrekm1v4kIDxRGJICMtT" target="_blank"><img src="https://asciinema.org/a/TeuRBLrekm1v4kIDxRGJICMtT.svg" /></a>\n\nbrain-prime\n<a href="https://asciinema.org/a/ourWQ1DbHbfYkGEi50QR5YTO6" target="_blank"><img src="https://asciinema.org/a/ourWQ1DbHbfYkGEi50QR5YTO6.svg" /></a>\n',
    'author': 'Egoru Froggy',
    'author_email': 'Impulsivethinker@yadex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Iamlilfroggy/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
